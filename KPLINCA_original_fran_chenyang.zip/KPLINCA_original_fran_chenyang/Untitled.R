setwd("~/Documents/huvud_hals/koll_pa_laget/KPLINCA_original_fran_chenyang")

library(jsonlite)


df <- data.frame(name = c("Indikator1", "Indikator2", "Indikator3", "Indikator4"), klinnum = c(45,30,70,90), klinden=c(99,97,97,97), regnum = c(50,102,102,102), regden = c(529,500,428,529), riknum = c(100,202,202,202), rikden = c(1029,1000,928,1029), history1 = c(10,10,5,7), history2 = c(22, 12,21,22), history3 = c(31,15,15,15), history4 = c(40,10,30,40), l1 = c(40,40,20,30), l2 = c(80,70,60,50), description = c("Beskrivning av Indikator1","Beskrivning av Indikator2","Beskrivning av Indikator3","Beskrivning av Indikator4"))
klin = "\"50001- Sahlgrenska Universitetssjukhus\""
diag = 199
beh = 188
prim = 1148
år = 2015


fileName <- "del1.txt"
del1 <- readChar(fileName, file.info(fileName)$size)
fileName <- "del2.txt"
del2 <- readChar(fileName, file.info(fileName)$size)

dfjson <- toJSON(df)
mitten <- paste0("\t\t var ser =", dfjson, "\n\t\t var klin = ", klin, "\n\t\t var diag =", diag, "\n\t\t var beh=", beh, "\n\t\t var prim =", prim,"\n\t\t var år =", år )

final = paste0(del1,"\n\t<script>\n",mitten,"\n\t</Script>\n",del2)

writeLines(final,"output.html")
